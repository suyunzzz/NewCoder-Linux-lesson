#include <stdio.h>
#include <string.h>

int main() {

    char * buf;

    strcpy(buf, "hello");

    return 0;
}