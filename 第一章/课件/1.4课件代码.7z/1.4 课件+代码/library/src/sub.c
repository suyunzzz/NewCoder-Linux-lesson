#include <stdio.h>
#include "head.h"

int subtract(int a, int b)
{
    return a-b;
}
