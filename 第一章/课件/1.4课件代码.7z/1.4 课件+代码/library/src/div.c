#include <stdio.h>

double divide(int a, int b)
{
    return (double)a/b;
}
